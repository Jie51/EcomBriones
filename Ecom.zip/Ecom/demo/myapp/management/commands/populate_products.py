from django.core.management.base import BaseCommand
from myapp.models import Category, Product
import requests
import os
from django.conf import settings

class Command(BaseCommand):
    help = 'Populate the database with sample categories and products'

    def handle(self, *args, **options):
        # Create categories
        categories_data = [
            {'name': 'Electronics', 'slug': 'electronics', 'description': 'Electronic devices and gadgets'},
            {'name': 'Clothing', 'slug': 'clothing', 'description': 'Fashion and apparel'},
            {'name': 'Books', 'slug': 'books', 'description': 'Books and literature'},
        ]

        for cat_data in categories_data:
            category, created = Category.objects.get_or_create(
                slug=cat_data['slug'],
                defaults=cat_data
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Created category: {category.name}'))
            else:
                self.stdout.write(f'Category {category.name} already exists')

        # Create products
        products_data = [
            {'name': 'Laptop', 'slug': 'laptop', 'description': 'A powerful laptop for work and play', 'price': 999.99, 'stock': 10, 'category_slug': 'electronics', 'image_url': 'https://via.placeholder.com/300x200/0000FF/FFFFFF.jpg'},
            {'name': 'Smartphone', 'slug': 'smartphone', 'description': 'Latest smartphone with advanced features', 'price': 699.99, 'stock': 20, 'category_slug': 'electronics', 'image_url': 'https://via.placeholder.com/300x200/FF0000/FFFFFF.jpg'},
            {'name': 'T-Shirt', 'slug': 't-shirt', 'description': 'Comfortable cotton t-shirt', 'price': 19.99, 'stock': 50, 'category_slug': 'clothing', 'image_url': 'https://via.placeholder.com/300x200/00FF00/FFFFFF.jpg'},
            {'name': 'Jeans', 'slug': 'jeans', 'description': 'Stylish denim jeans', 'price': 49.99, 'stock': 30, 'category_slug': 'clothing', 'image_url': 'https://via.placeholder.com/300x200/FFFF00/000000.jpg'},
            {'name': 'Python Book', 'slug': 'python-book', 'description': 'Learn Python programming', 'price': 29.99, 'stock': 15, 'category_slug': 'books', 'image_url': 'https://via.placeholder.com/300x200/FF00FF/FFFFFF.jpg'},
            {'name': 'Django Book', 'slug': 'django-book', 'description': 'Master Django web framework', 'price': 39.99, 'stock': 12, 'category_slug': 'books', 'image_url': 'https://via.placeholder.com/300x200/00FFFF/000000.jpg'},
        ]

        for prod_data in products_data:
            category = Category.objects.get(slug=prod_data.pop('category_slug'))
            image_url = prod_data.pop('image_url')
            product, created = Product.objects.get_or_create(
                slug=prod_data['slug'],
                defaults={**prod_data, 'category': category}
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Created product: {product.name}'))
            else:
                self.stdout.write(f'Product {product.name} already exists')

            # Download image if not exists
            filename = f"{product.slug}.jpg"
            image_path = os.path.join(settings.MEDIA_ROOT, 'products', filename)
            if not os.path.exists(image_path):
                os.makedirs(os.path.dirname(image_path), exist_ok=True)
                try:
                    response = requests.get(image_url, timeout=10)
                    if response.status_code == 200:
                        with open(image_path, 'wb') as f:
                            f.write(response.content)
                        product.image = f'products/{filename}'
                        product.save()
                        self.stdout.write(f'Downloaded image for {product.name}')
                    else:
                        self.stdout.write(self.style.WARNING(f'Failed to download image for {product.name}'))
                except requests.exceptions.RequestException as e:
                    self.stdout.write(self.style.WARNING(f'Failed to download image for {product.name}: {e}'))
